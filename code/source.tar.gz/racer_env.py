"""CloudRacer Curvas GUI: ambiente 2D sinuoso, sem pygame.
Adaptação didática inspirada no contrato público de sensores do projeto
akshaybhandare/neural_network (MIT); não contém o código do repositório.
"""
import math

ANGLES = (-90, -55, -25, 0, 25, 55, 90)
CX, CY, RX, RY = 430.0, 285.0, 262.0, 172.0
# Duas ondulações criam curvas adicionais, mantendo o circuito fechado.
# O viewer recebe exatamente estes parâmetros para desenhar a mesma pista.
WAVES = ((3, 0.08, 0.40), (5, 0.03, -0.80))
TRACK_WIDTH = 110.0
MAX_SPEED = 8.0


def clamp(x, lo, hi):
    return max(lo, min(hi, x))


def wrap(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


def center_angle(x, y):
    """Ângulo parametrizado da pista sinuosa (cresce ao completar a volta)."""
    return math.atan2((y - CY) / RY, (x - CX) / RX)


def shape(theta):
    """Fator radial e derivada: ondulação contínua com 3 e 5 curvas."""
    r, dr = 1.0, 0.0
    for freq, amplitude, shift in WAVES:
        r += amplitude * math.sin(freq * theta + shift)
        dr += amplitude * freq * math.cos(freq * theta + shift)
    return r, dr


def center_point(theta):
    r, _ = shape(theta)
    return CX + RX * r * math.cos(theta), CY + RY * r * math.sin(theta)


def tangent(theta):
    r, dr = shape(theta)
    dx = RX * (dr * math.cos(theta) - r * math.sin(theta))
    dy = RY * (dr * math.sin(theta) + r * math.cos(theta))
    return math.atan2(dy, dx)


def signed_distance(x, y):
    """Distância transversal aproximada ao centro da pista sinuosa.

    Equivale à projeção normal local, sem procurar pontos numa polilinha.
    A aproximação é eficiente nas milhões de leituras dos sensores.
    """
    ux = (x - CX) / RX
    uy = (y - CY) / RY
    rho = math.hypot(ux, uy)
    if rho < 1e-8:
        return -min(RX, RY)
    theta = math.atan2(uy, ux)
    r, dr = shape(theta)
    tx = RX * (dr * math.cos(theta) - r * math.sin(theta))
    ty = RY * (dr * math.sin(theta) + r * math.cos(theta))
    return (rho - r) * (RX * RY * r) / max(1e-9, math.hypot(tx, ty))


class CarRacingEnv:
    """Observação = 7 sensores, velocidade, erro angular, deslocamento lateral.
    Ação = steer e throttle, ambos contínuos. Sem dependência de bibliotecas externas.
    """
    def __init__(self, max_steps=360, start_phase=0.0):
        self.max_steps = max_steps
        self.start_phase = start_phase
        self.reset()

    def reset(self, phase=None):
        theta = self.start_phase if phase is None else phase
        self.x, self.y = center_point(theta)
        self.angle = tangent(theta)
        self.speed = 2.7
        self.prev_theta = theta
        self.total_phase = 0.0
        self.steps = 0
        self.crashed = False
        return self.observe()

    def on_track(self, x, y):
        return abs(signed_distance(x, y)) <= TRACK_WIDTH / 2

    def sensors(self):
        result = []
        for deg in ANGLES:
            ang = self.angle + math.radians(deg)
            ux, uy = math.cos(ang), math.sin(ang)
            length = 176.0
            for dist in range(8, 177, 8):
                if not self.on_track(self.x + dist * ux, self.y + dist * uy):
                    length = float(dist)
                    break
            result.append(round(length / 176.0, 5))
        return result

    def observe(self):
        phase = center_angle(self.x, self.y)
        err = wrap(tangent(phase) - self.angle)
        off = signed_distance(self.x, self.y)
        return self.sensors() + [self.speed / MAX_SPEED,
                                 clamp(err / math.pi, -1, 1),
                                 clamp(off / (TRACK_WIDTH / 2), -1, 1)]

    def step(self, action):
        steer, throttle = (clamp(float(action[0]), -1, 1),
                           clamp(float(action[1]), 0, 1))
        self.speed = clamp(self.speed * 0.981 + 0.31 * throttle, 0, MAX_SPEED)
        self.angle += 0.058 * steer * (self.speed / 6.0)
        self.x += math.cos(self.angle) * self.speed
        self.y += math.sin(self.angle) * self.speed
        self.steps += 1
        theta = center_angle(self.x, self.y)
        delta = wrap(theta - self.prev_theta)
        self.total_phase += delta
        self.prev_theta = theta
        progress = max(-0.3, min(delta, 0.3))
        self.crashed = not self.on_track(self.x, self.y)
        completed = self.total_phase >= 2 * math.pi
        truncated = self.steps >= self.max_steps
        # Recompensa de progresso e de centralização + penalidade de colisão.
        reward = 55.0 * progress - 0.012 * abs(signed_distance(self.x, self.y)) - 0.06
        if progress < 0:
            reward += 30.0 * progress
        if self.crashed:
            reward -= 14
        if completed:
            reward += 40
        return self.observe(), float(reward), bool(self.crashed or completed or truncated), {
            'crashed': self.crashed,
            'lap_completed': bool(completed),
            'steps': self.steps,
            'phase': self.total_phase,
            'distance_to_center': round(float(signed_distance(self.x, self.y)), 2),
        }

    def snapshot(self, readings=None):
        return [round(self.x, 2), round(self.y, 2), round(self.angle, 3),
                round(self.speed, 2), readings or self.sensors()]
