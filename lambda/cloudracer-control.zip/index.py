"""Controlador para Lambda criada pelo CloudFormation: apenas boto3 e stdlib.
Evento start/status/publish via botão Test no console Lambda.
"""
import boto3
from botocore.exceptions import ClientError
from datetime import datetime, timezone
import io
import json
import math
import os
import tarfile
import uuid

S3 = boto3.client('s3')
SM = boto3.client('sagemaker')
BUCKET = os.environ['LAB_BUCKET']
ROLE = os.environ['LAB_ROLE_ARN']
REGION = os.environ.get('AWS_REGION', 'us-east-1')
PREFIX = 'cloudracer-original-'
IMAGE = ('763104351884.dkr.ecr.' + REGION +
         '.amazonaws.com/pytorch-training:2.10.0-cpu-py313-ubuntu22.04-sagemaker')


def latest_job():
    jobs = SM.list_training_jobs(NameContains=PREFIX, SortBy='CreationTime',
                                 SortOrder='Descending', MaxResults=20)['TrainingJobSummaries']
    matches = [j for j in jobs if j['TrainingJobName'].startswith(PREFIX)]
    if not matches:
        raise ValueError('Nenhum treinamento CloudRacer localizado. Inicie a ação treinar.')
    return matches[0]['TrainingJobName']


def handler(event, context):
    event = event or {}
    action = (event.get('acao') or 'status').strip().lower()
    if action == 'treinar':
        S3.head_object(Bucket=BUCKET, Key='code/source.tar.gz')
        episodes = int(event.get('episodios', 100))
        steps = int(event.get('max_passos', 350))
        seed = int(event.get('semente', 42))
        learning_rate = float(event.get('learning_rate', 0.001))
        if not (5 <= episodes <= 400 and 100 <= steps <= 1000 and 0 <= seed <= 999999):
            raise ValueError('Limites: episodios 5..400, max_passos 100..1000, semente 0..999999')
        if not (math.isfinite(learning_rate) and 0.00001 <= learning_rate <= 0.02):
            raise ValueError('learning_rate deve ser entre 0.00001 e 0.02')
        job = PREFIX + datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-') + uuid.uuid4().hex[:5]
        response = SM.create_training_job(
            TrainingJobName=job,
            AlgorithmSpecification={
                'TrainingImage': IMAGE,
                'TrainingInputMode': 'File',
                'MetricDefinitions': [
                    {'Name': 'train:reward', 'Regex': r'metric_train_reward=([-+]?[0-9]*\.?[0-9]+)'},
                    {'Name': 'eval:reward', 'Regex': r'metric_eval_reward=([-+]?[0-9]*\.?[0-9]+)'},
                ]
            },
            HyperParameters={
                'sagemaker_program': 'train.py',
                'sagemaker_submit_directory': 's3://' + BUCKET + '/code/source.tar.gz',
                'episodes': str(episodes),
                'max-steps': str(steps),
                'seed': str(seed),
                'eval-every': '10',
                'learning-rate': str(learning_rate)
            },
            RoleArn=ROLE,
            OutputDataConfig={'S3OutputPath': 's3://' + BUCKET + '/jobs/'},
            ResourceConfig={'InstanceCount': 1, 'InstanceType': 'ml.m5.large',
                            'VolumeSizeInGB': 30},
            StoppingCondition={'MaxRuntimeInSeconds': 1200},
            Tags=[{'Key': 'Project', 'Value': 'CloudRacerOriginalGUI'}]
        )
        return {'acao': action, 'job': job, 'status': 'Iniciado',
                'learning_rate': learning_rate,
                'training_job_arn': response['TrainingJobArn'],
                'imagem': IMAGE,
                'aviso': 'Verifique treinamento no SageMaker. Limite configurado: 20 minutos.'}

    if action in ('status', 'publicar'):
        job = event.get('job') or latest_job()
        if not (isinstance(job, str) and job.startswith(PREFIX)):
            raise ValueError('Job deve ter prefixo cloudracer-original-')
        detail = SM.describe_training_job(TrainingJobName=job)
        status = detail['TrainingJobStatus']
        result = {'acao': action, 'job': job, 'status': status}
        if status == 'Failed':
            result['motivo'] = detail.get('FailureReason', 'Confira o CloudWatch Logs')
        if action == 'status':
            return result
        if status != 'Completed':
            raise ValueError('O treinamento ainda não terminou: ' + status)
        uri = detail['ModelArtifacts']['S3ModelArtifacts']
        prefix = 's3://' + BUCKET + '/'
        if not uri.startswith(prefix):
            raise ValueError('Arquivo do modelo fora do bucket do laboratório')
        key = uri[len(prefix):]
        zipped = S3.get_object(Bucket=BUCKET, Key=key)['Body'].read()
        outputs = {}
        with tarfile.open(fileobj=io.BytesIO(zipped), mode='r:gz') as bundle:
            for name in ('viewer.html', 'metrics.csv', 'summary.json'):
                members = [m for m in bundle.getmembers() if m.name.lstrip('./') == name and m.isfile()]
                if not members:
                    raise ValueError('Artefato não contém ' + name)
                member = members[0]
                if member.size > 5 * 1024 * 1024:
                    raise ValueError('Artefato muito grande: ' + name)
                body = bundle.extractfile(member).read()
                dest = 'resultados/' + job + '/' + name
                S3.put_object(Bucket=BUCKET, Key=dest, Body=body,
                              ContentType={'viewer.html': 'text/html; charset=utf-8',
                                           'metrics.csv': 'text/csv; charset=utf-8',
                                           'summary.json': 'application/json'}[name])
                outputs[name] = dest
        result['arquivos_s3'] = outputs
        result['instrucoes'] = 'No S3, selecione resultados/.../viewer.html > Download; abra localmente no navegador.'
        return result
    raise ValueError('acao: treinar, status ou publicar')
